For Stockers, we had to create a custom unit test system that could compensate the fact that the application runs during real time. 
To do so, we compared the application’s current state with expected state and received an output. 

Instructions:
The Unit Tests for Stockers runs simultaneously while the application is functioning. 
To see the results of these tests you simply need to navigate to “Android Monitor” at the bottom of Android Studio while Stockers is running. 
This displays various outputs from the application. 
In the search bar type in “State” to filter out the outputs. 
After applying this filter, all outputs should pertain to the unit tests. 
When switching between pages, you will see how the states change and whether or not the app is successful at switching between pages. 

When you log in, you will see the output: “LoginState: True”
When you make a purchase (assuming you have enough money), you will see: “PurchaseState: True”

You will see the outcome of most supported functionalities in the application. 
